package com.simple.labelprint

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

@SuppressLint("MissingPermission")
class MainActivity : Activity() {

    private val reqPerm = 1
    private val sizes = listOf(0, 24, 32, 40, 56, 72)
    private val sizeNames = listOf(
        "Huruf otomatis", "Huruf kecil", "Huruf sedang",
        "Huruf besar", "Huruf sangat besar", "Huruf jumbo"
    )

    private var adapter: BluetoothAdapter? = null
    private lateinit var printer: PrinterConnection
    private var devices: List<BluetoothDevice> = emptyList()
    @Volatile private var busy = false

    private lateinit var spPrinter: Spinner
    private lateinit var tvStatus: TextView
    private lateinit var rbTspl: RadioButton
    private lateinit var rbEscpos: RadioButton
    private lateinit var etText: EditText
    private lateinit var spSize: Spinner
    private lateinit var spAlign: Spinner
    private lateinit var cbBold: CheckBox
    private lateinit var cbBorder: CheckBox
    private lateinit var cbRotate: CheckBox
    private lateinit var ivPreview: ImageView
    private lateinit var etCopies: EditText
    private lateinit var etGap: EditText
    private lateinit var btnPrint: Button

    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        printer = PrinterConnection(adapter)

        spPrinter = findViewById(R.id.spPrinter)
        tvStatus = findViewById(R.id.tvStatus)
        rbTspl = findViewById(R.id.rbTspl)
        rbEscpos = findViewById(R.id.rbEscpos)
        etText = findViewById(R.id.etText)
        spSize = findViewById(R.id.spSize)
        spAlign = findViewById(R.id.spAlign)
        cbBold = findViewById(R.id.cbBold)
        cbBorder = findViewById(R.id.cbBorder)
        cbRotate = findViewById(R.id.cbRotate)
        ivPreview = findViewById(R.id.ivPreview)
        etCopies = findViewById(R.id.etCopies)
        etGap = findViewById(R.id.etGap)
        btnPrint = findViewById(R.id.btnPrint)

        setItems(spSize, sizeNames)
        setItems(spAlign, listOf("Rata tengah", "Rata kiri", "Rata kanan"))

        // Pulihkan pengaturan terakhir
        etText.setText(prefs.getString("text", ""))
        if (prefs.getBoolean("escpos", true)) rbEscpos.isChecked = true
        spSize.setSelection(prefs.getInt("size", 0).coerceIn(0, sizes.size - 1))
        spAlign.setSelection(prefs.getInt("align", 0).coerceIn(0, 2))
        cbBold.isChecked = prefs.getBoolean("bold", true)
        cbBorder.isChecked = prefs.getBoolean("border", false)
        cbRotate.isChecked = prefs.getBoolean("rotate", false)
        etGap.setText(prefs.getInt("gap", 2).toString())

        val refresh = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = updatePreview()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spSize.onItemSelectedListener = refresh
        spAlign.onItemSelectedListener = refresh
        listOf(cbBold, cbBorder, cbRotate).forEach { it.setOnCheckedChangeListener { _, _ -> updatePreview() } }
        etText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = updatePreview()
        })
        findViewById<RadioGroup>(R.id.rgMode).setOnCheckedChangeListener { _, _ -> saveSettings() }

        findViewById<Button>(R.id.btnRefresh).setOnClickListener { loadPrinters() }
        findViewById<Button>(R.id.btnConnect).setOnClickListener { connectSelected() }
        btnPrint.setOnClickListener { print() }

        updatePreview()
        if (hasBtPermission()) loadPrinters() else requestBtPermission()
    }

    override fun onDestroy() {
        printer.close()
        super.onDestroy()
    }

    private fun setItems(sp: Spinner, items: List<String>) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun status(msg: String) = runOnUiThread { tvStatus.text = msg }

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    /** Posisi spinner rata: 0 tengah, 1 kiri, 2 kanan  ->  Label: 0 kiri, 1 tengah, 2 kanan */
    private fun alignValue(): Int = when (spAlign.selectedItemPosition) { 1 -> 0; 2 -> 2; else -> 1 }

    private fun renderLabel(): Bitmap = Label.render(
        etText.text.toString(),
        sizes[spSize.selectedItemPosition.coerceIn(0, sizes.size - 1)],
        cbBold.isChecked,
        alignValue(),
        cbBorder.isChecked
    )

    private fun updatePreview() {
        ivPreview.setImageBitmap(renderLabel())
        saveSettings()
    }

    private fun saveSettings() {
        prefs.edit()
            .putString("text", etText.text.toString())
            .putBoolean("escpos", rbEscpos.isChecked)
            .putInt("size", spSize.selectedItemPosition)
            .putInt("align", spAlign.selectedItemPosition)
            .putBoolean("bold", cbBold.isChecked)
            .putBoolean("border", cbBorder.isChecked)
            .putBoolean("rotate", cbRotate.isChecked)
            .putInt("gap", etGap.text.toString().toIntOrNull() ?: 2)
            .apply()
    }

    // ---------- Bluetooth ----------

    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun requestBtPermission() {
        if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), reqPerm)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqPerm) {
            if (hasBtPermission()) loadPrinters() else status("Izin Bluetooth ditolak. Aktifkan di Pengaturan > Aplikasi.")
        }
    }

    private fun loadPrinters() {
        if (!hasBtPermission()) { requestBtPermission(); return }
        val a = adapter
        if (a == null) { status("HP ini tidak punya Bluetooth"); return }
        if (!a.isEnabled) { status("Bluetooth mati. Nyalakan dulu, lalu tekan Muat ulang."); return }
        devices = try { a.bondedDevices.toList().sortedBy { it.name ?: "" } } catch (e: Exception) { emptyList() }
        if (devices.isEmpty()) {
            setItems(spPrinter, listOf("(Belum ada perangkat ter-pair)"))
            status("Pair printer dulu di Pengaturan Bluetooth HP, lalu tekan Muat ulang.")
            return
        }
        setItems(spPrinter, devices.map { "${it.name ?: "Tanpa nama"} (${it.address})" })
        val idx = devices.indexOfFirst { it.address == prefs.getString("printer", null) }
        if (idx >= 0) spPrinter.setSelection(idx)
        status(if (printer.isConnected) "Tersambung" else "Pilih printer lalu tekan Sambungkan")
    }

    private fun selectedDevice(): BluetoothDevice? = devices.getOrNull(spPrinter.selectedItemPosition)

    private fun connectSelected() {
        val d = selectedDevice() ?: run { toast("Pilih printer dulu"); return }
        if (busy) return
        busy = true
        status("Menyambungkan ke ${d.name}...")
        Thread {
            try {
                printer.connect(d)
                prefs.edit().putString("printer", d.address).apply()
                status("Tersambung ke ${d.name}")
            } catch (e: Exception) {
                status("Gagal tersambung. Pastikan printer menyala & tidak dipakai HP lain.")
            } finally {
                busy = false
            }
        }.start()
    }

    private fun print() {
        if (busy) return
        val d = selectedDevice() ?: run { toast("Pilih printer dulu"); return }
        if (etText.text.isBlank()) { toast("Isi label masih kosong"); return }
        val copies = (etCopies.text.toString().toIntOrNull() ?: 1).coerceIn(1, 999)
        val gap = (etGap.text.toString().toIntOrNull() ?: 2).coerceIn(0, 10)
        val rotate = cbRotate.isChecked
        val tspl = rbTspl.isChecked
        val bmp = renderLabel()
        saveSettings()

        busy = true
        btnPrint.isEnabled = false
        status("Mencetak $copies label...")
        Thread {
            try {
                val data = if (tspl) Label.tspl(bmp, copies, gap, rotate) else Label.escpos(bmp, copies, gap, rotate)
                if (!printer.isConnected || printer.address != d.address) {
                    status("Menyambungkan ke ${d.name}...")
                    printer.connect(d)
                    prefs.edit().putString("printer", d.address).apply()
                }
                try {
                    printer.write(data)
                } catch (e: Exception) {
                    printer.connect(d)
                    printer.write(data)
                }
                status("Selesai: $copies label dicetak")
            } catch (e: Exception) {
                status("Gagal mencetak: ${e.message}")
            } finally {
                busy = false
                runOnUiThread { btnPrint.isEnabled = true }
            }
        }.start()
    }
}
