package com.simple.labelprint

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import java.io.ByteArrayOutputStream

/** Menggambar label 50x20 mm (203 dpi = 400 x 160 dot) dan mengubahnya jadi perintah printer. */
object Label {
    const val W = 400
    const val H = 160

    /** sizePx = 0 berarti ukuran huruf otomatis (sebesar mungkin). align: 0 kiri, 1 tengah, 2 kanan */
    fun render(text: String, sizePx: Int, bold: Boolean, align: Int, border: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)

        val lines = text.replace("\r\n", "\n").trimEnd('\n').split("\n")
        val margin = if (border) 14f else 6f
        val maxW = W - 2 * margin
        val maxH = H - 2 * margin

        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }

        var size = if (sizePx > 0) sizePx.toFloat() else 140f
        if (sizePx == 0) {
            while (size > 10f) {
                p.textSize = size
                val fm = p.fontMetrics
                val lineH = fm.descent - fm.ascent
                val tw = lines.maxOf { p.measureText(it) }
                if (tw <= maxW && lineH * lines.size <= maxH) break
                size -= 1f
            }
        }
        p.textSize = size
        val fm = p.fontMetrics
        val lineH = fm.descent - fm.ascent
        var y = (H - lineH * lines.size) / 2f - fm.ascent
        for (line in lines) {
            val tw = p.measureText(line)
            val x = when (align) {
                0 -> margin
                2 -> W - margin - tw
                else -> (W - tw) / 2f
            }
            c.drawText(line, x, y, p)
            y += lineH
        }

        if (border) {
            val bp = Paint().apply {
                color = Color.BLACK
                style = Paint.Style.STROKE
                strokeWidth = 4f
            }
            c.drawRect(4f, 4f, W - 4f, H - 4f, bp)
        }
        return bmp
    }

    fun rotate180(src: Bitmap): Bitmap {
        val m = Matrix()
        m.postRotate(180f)
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /** true = titik hitam */
    private fun mono(bmp: Bitmap): BooleanArray {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        return BooleanArray(w * h) { i ->
            val p = px[i]
            val lum = 0.299f * ((p shr 16) and 0xFF) + 0.587f * ((p shr 8) and 0xFF) + 0.114f * (p and 0xFF)
            lum < 128f
        }
    }

    /** Untuk printer label (TSPL): Xprinter, HPRT, Gprinter, dll. */
    fun tspl(bmp: Bitmap, copies: Int, gapMm: Int, rotate: Boolean): ByteArray {
        val w = bmp.width
        val h = bmp.height
        val black = mono(bmp)
        val wb = (w + 7) / 8
        val out = ByteArrayOutputStream()
        val head = "SIZE 50 mm,20 mm\r\n" +
            "GAP $gapMm mm,0 mm\r\n" +
            "DIRECTION ${if (rotate) 1 else 0}\r\n" +
            "REFERENCE 0,0\r\n" +
            "CLS\r\n" +
            "BITMAP 0,0,$wb,$h,0,"
        out.write(head.toByteArray(Charsets.US_ASCII))
        for (y in 0 until h) {
            for (xb in 0 until wb) {
                var v = 0xFF // di TSPL: bit 1 = putih, 0 = hitam
                for (bit in 0 until 8) {
                    val x = xb * 8 + bit
                    if (x < w && black[y * w + x]) v = v and (0x80 shr bit).inv()
                }
                out.write(v and 0xFF)
            }
        }
        out.write("\r\nPRINT 1,${copies.coerceIn(1, 999)}\r\n".toByteArray(Charsets.US_ASCII))
        return out.toByteArray()
    }

    /**
     * Untuk printer struk biasa (ESC/POS) yang diisi kertas label. Lebar 384 dot = 48 mm.
     * Printer struk tidak punya sensor celah, jadi setiap label dimajukan tepat
     * (20 mm + jarak antar label) supaya posisi cetak tidak bergeser.
     */
    fun escpos(bmp: Bitmap, copies: Int, gapMm: Int, rotate: Boolean): ByteArray {
        var b = Bitmap.createScaledBitmap(bmp, 384, (bmp.height * 384) / bmp.width, true)
        if (rotate) b = rotate180(b)
        val w = b.width
        val h = b.height
        val black = mono(b)
        val wb = (w + 7) / 8
        val img = ByteArrayOutputStream()
        img.write(byteArrayOf(
            0x1D, 0x76, 0x30, 0x00,
            (wb and 0xFF).toByte(), ((wb shr 8) and 0xFF).toByte(),
            (h and 0xFF).toByte(), ((h shr 8) and 0xFF).toByte()
        ))
        for (y in 0 until h) {
            for (xb in 0 until wb) {
                var v = 0
                for (bit in 0 until 8) {
                    val x = xb * 8 + bit
                    if (x < w && black[y * w + x]) v = v or (0x80 shr bit)
                }
                img.write(v)
            }
        }
        val one = img.toByteArray()
        // Total maju per label = (20 mm + gap) x 8 dot/mm, dikurangi tinggi gambar
        val feed = (20 + gapMm) * 8 - h
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x1B, 0x40))
        out.write(byteArrayOf(0x1B, 0x33, 0x00)) // jarak baris 0
        repeat(copies.coerceIn(1, 999)) {
            out.write(one)
            var f = feed
            while (f > 0) {
                val n = minOf(f, 255)
                out.write(byteArrayOf(0x1B, 0x4A, n.toByte())) // maju n dot
                f -= n
            }
        }
        out.write(byteArrayOf(0x1B, 0x32)) // jarak baris normal lagi
        return out.toByteArray()
    }
}
