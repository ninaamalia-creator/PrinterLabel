# Label Printer

Aplikasi Android untuk mencetak label 50 x 20 mm ke printer termal Bluetooth (TSPL atau ESC/POS).
