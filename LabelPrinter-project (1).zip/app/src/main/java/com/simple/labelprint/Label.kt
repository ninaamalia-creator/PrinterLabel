package com.simple.labelprint

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import java.io.ByteArrayOutputStream

/** Semua isi label. Ukuran dalam mm, digambar pada 8 dot/mm (203 dpi). */
class LabelSpec(
    val wMm: Int,
    val hMm: Int,
    val text: String,
    val sizePx: Int,        // 0 = otomatis
    val bold: Boolean,
    val align: Int,         // 0 kiri, 1 tengah, 2 kanan
    val frame: Int,         // index Label.FRAMES
    val image: Bitmap?,
    val dither: Boolean,
    val codeFormat: BarcodeFormat?, // null = tanpa barcode
    val codeText: String,
    val codeShowText: Boolean
)

class LabelResult(val bitmap: Bitmap, val warning: String?)

object Label {
    const val DOTS_PER_MM = 8
    const val ESC_WIDTH = 384 // lebar cetak printer struk 58 mm (48 mm)

    val FRAMES = listOf(
        "Tanpa bingkai",
        "Garis tipis",
        "Garis tebal",
        "Sudut membulat",
        "Garis ganda",
        "Garis putus-putus",
        "Hiasan sudut",
        "Judul blok hitam (baris 1)"
    )
    private val FRAME_MARGIN = intArrayOf(6, 12, 16, 14, 18, 12, 14, 10)

    val CODE_TYPES: List<Pair<String, BarcodeFormat?>> = listOf(
        "Tanpa barcode" to null,
        "QR Code" to BarcodeFormat.QR_CODE,
        "Code 128" to BarcodeFormat.CODE_128,
        "EAN-13 (12/13 angka)" to BarcodeFormat.EAN_13,
        "Code 39" to BarcodeFormat.CODE_39
    )

    // ---------------- Menggambar label ----------------

    fun render(s: LabelSpec): LabelResult {
        val w = s.wMm * DOTS_PER_MM
        val h = s.hMm * DOTS_PER_MM
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        var warning: String? = null

        val m = FRAME_MARGIN[s.frame.coerceIn(0, FRAMES.size - 1)].toFloat()
        val area = RectF(m, m, w - m, h - m)

        val lines = s.text.replace("\r\n", "\n").trimEnd('\n').split("\n").toMutableList()
        if (lines.size == 1 && lines[0].isBlank()) lines.clear()

        // Template judul blok hitam: baris pertama jadi judul putih di atas blok hitam
        if (s.frame == 7 && lines.isNotEmpty()) {
            val bandH = if (lines.size == 1) area.height() else area.height() * 0.38f
            val band = RectF(area.left, area.top, area.right, area.top + bandH)
            val bp = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL }
            c.drawRoundRect(band, 6f, 6f, bp)
            val inner = RectF(band.left + 6, band.top + 2, band.right - 6, band.bottom - 2)
            drawText(c, listOf(lines.removeAt(0)), inner, 0, true, 1, Color.WHITE)
            area.top = band.bottom + 4
        }

        // Gambar / logo di kiri
        val img = s.image
        if (img != null && area.height() > 8 && area.width() > 16) {
            val boxH = area.height()
            val maxW = if (lines.isEmpty() && s.codeFormat == null) area.width() else area.width() * 0.4f
            var dw = boxH * img.width / img.height
            var dh = boxH
            if (dw > maxW) { dh = dh * maxW / dw; dw = maxW }
            val mono = toMono(Bitmap.createScaledBitmap(img, dw.toInt().coerceAtLeast(1), dh.toInt().coerceAtLeast(1), true), s.dither)
            val x = if (lines.isEmpty() && s.codeFormat == null) area.left + (area.width() - dw) / 2f else area.left
            c.drawBitmap(mono, x, area.top + (boxH - dh) / 2f, null)
            if (!(lines.isEmpty() && s.codeFormat == null)) area.left += dw + 6
        }

        // Barcode / QR
        val fmt = s.codeFormat
        val codeText = s.codeText.trim()
        if (fmt != null && codeText.isNotEmpty()) {
            try {
                if (fmt == BarcodeFormat.QR_CODE) {
                    val qrMax = if (lines.isEmpty()) minOf(area.height(), area.width()) else minOf(area.height(), area.width() * 0.5f)
                    val mat = MultiFormatWriter().encode(codeText, fmt, 0, 0, mapOf(EncodeHintType.MARGIN to 0, EncodeHintType.CHARACTER_SET to "UTF-8"))
                    val scale = (qrMax / mat.width).toInt()
                    if (scale < 1) {
                        warning = "Isi QR terlalu panjang untuk ukuran label ini"
                    } else {
                        val size = mat.width * scale
                        val x0 = if (lines.isEmpty()) area.left + (area.width() - size) / 2f else area.right - size
                        val y0 = area.top + (area.height() - size) / 2f
                        val p = Paint().apply { color = Color.BLACK }
                        for (yy in 0 until mat.height) for (xx in 0 until mat.width) {
                            if (mat.get(xx, yy)) c.drawRect(x0 + xx * scale, y0 + yy * scale, x0 + (xx + 1) * scale, y0 + (yy + 1) * scale, p)
                        }
                        if (lines.isNotEmpty()) area.right -= size + 6
                    }
                } else {
                    val mat = MultiFormatWriter().encode(codeText, fmt, 0, 1, mapOf(EncodeHintType.MARGIN to 0))
                    val scale = (area.width() / mat.width).toInt().coerceAtMost(4)
                    if (scale < 1) {
                        warning = "Barcode terlalu panjang untuk ukuran label ini"
                    } else {
                        val zoneH = if (lines.isEmpty()) area.height() else area.height() * 0.5f
                        val txtH = if (s.codeShowText) 22f else 0f
                        val barH = zoneH - txtH
                        val bw = mat.width * scale
                        val x0 = area.left + (area.width() - bw) / 2f
                        val y0 = area.bottom - zoneH
                        val p = Paint().apply { color = Color.BLACK }
                        for (xx in 0 until mat.width) {
                            if (mat.get(xx, 0)) c.drawRect(x0 + xx * scale, y0, x0 + (xx + 1) * scale, y0 + barH, p)
                        }
                        if (s.codeShowText) {
                            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = Color.BLACK; textSize = 20f; textAlign = Paint.Align.CENTER
                            }
                            c.drawText(codeText, area.centerX(), area.bottom - 3f, tp)
                        }
                        area.bottom = y0 - 4
                    }
                }
            } catch (e: Exception) {
                warning = "Isi barcode tidak sesuai format (${e.message ?: "cek angka/huruf"})"
            }
        }

        // Teks
        if (lines.isNotEmpty() && area.height() > 8 && area.width() > 8) {
            drawText(c, lines, area, s.sizePx, s.bold, s.align, Color.BLACK)
        }

        drawFrame(c, s.frame, w.toFloat(), h.toFloat())
        return LabelResult(bmp, warning)
    }

    private fun drawText(c: Canvas, lines: List<String>, r: RectF, sizePx: Int, bold: Boolean, align: Int, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        var size = if (sizePx > 0) sizePx.toFloat() else 200f
        while (size > 8f) {
            p.textSize = size
            val fm = p.fontMetrics
            val lh = fm.descent - fm.ascent
            val tw = lines.maxOf { p.measureText(it) }
            val fits = tw <= r.width() && lh * lines.size <= r.height()
            if (fits || sizePx > 0) break
            size -= 1f
        }
        p.textSize = size
        val fm = p.fontMetrics
        val lh = fm.descent - fm.ascent
        var y = r.top + (r.height() - lh * lines.size) / 2f - fm.ascent
        c.save()
        c.clipRect(r)
        for (line in lines) {
            val tw = p.measureText(line)
            val x = when (align) {
                0 -> r.left
                2 -> r.right - tw
                else -> r.left + (r.width() - tw) / 2f
            }
            c.drawText(line, x, y, p)
            y += lh
        }
        c.restore()
    }

    private fun drawFrame(c: Canvas, frame: Int, w: Float, h: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.STROKE }
        when (frame) {
            1 -> { p.strokeWidth = 3f; c.drawRect(3f, 3f, w - 3f, h - 3f, p) }
            2 -> { p.strokeWidth = 8f; c.drawRect(5f, 5f, w - 5f, h - 5f, p) }
            3 -> { p.strokeWidth = 4f; c.drawRoundRect(RectF(4f, 4f, w - 4f, h - 4f), 22f, 22f, p) }
            4 -> {
                p.strokeWidth = 4f; c.drawRect(3f, 3f, w - 3f, h - 3f, p)
                p.strokeWidth = 2f; c.drawRect(11f, 11f, w - 11f, h - 11f, p)
            }
            5 -> {
                p.strokeWidth = 4f
                p.pathEffect = DashPathEffect(floatArrayOf(14f, 8f), 0f)
                c.drawRect(4f, 4f, w - 4f, h - 4f, p)
            }
            6 -> {
                p.strokeWidth = 6f
                val l = minOf(w, h) * 0.22f
                val o = 5f
                c.drawLine(o, o, o + l, o, p); c.drawLine(o, o, o, o + l, p)
                c.drawLine(w - o, o, w - o - l, o, p); c.drawLine(w - o, o, w - o, o + l, p)
                c.drawLine(o, h - o, o + l, h - o, p); c.drawLine(o, h - o, o, h - o - l, p)
                c.drawLine(w - o, h - o, w - o - l, h - o, p); c.drawLine(w - o, h - o, w - o, h - o - l, p)
            }
            7 -> { p.strokeWidth = 3f; c.drawRoundRect(RectF(3f, 3f, w - 3f, h - 3f), 8f, 8f, p) }
        }
    }

    /** Ubah gambar jadi hitam-putih murni (dengan dithering untuk foto). */
    private fun toMono(src: Bitmap, dither: Boolean): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val g = FloatArray(w * h) { i ->
            val p = px[i]
            val a = (p ushr 24) and 0xFF
            val lum = 0.299f * ((p shr 16) and 0xFF) + 0.587f * ((p shr 8) and 0xFF) + 0.114f * (p and 0xFF)
            255f - a * (255f - lum) / 255f
        }
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            val old = g[i]
            val nw = if (old < 128f) 0f else 255f
            px[i] = if (nw == 0f) Color.BLACK else Color.WHITE
            if (dither) {
                val err = old - nw
                if (x + 1 < w) g[i + 1] += err * 7f / 16f
                if (y + 1 < h) {
                    if (x > 0) g[i + w - 1] += err * 3f / 16f
                    g[i + w] += err * 5f / 16f
                    if (x + 1 < w) g[i + w + 1] += err / 16f
                }
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    // ---------------- Perintah printer ----------------

    fun rotate180(src: Bitmap): Bitmap {
        val m = Matrix()
        m.postRotate(180f)
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun black(bmp: Bitmap): BooleanArray {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        return BooleanArray(w * h) { i ->
            val p = px[i]
            0.299f * ((p shr 16) and 0xFF) + 0.587f * ((p shr 8) and 0xFF) + 0.114f * (p and 0xFF) < 128f
        }
    }

    /** Printer struk biasa (ESC/POS), contoh MP-58A. */
    fun escpos(label: Bitmap, hMm: Int, copies: Int, gapMm: Int, rotate: Boolean): ByteArray {
        // Sesuaikan ke lebar cetak 384 dot: label lebar dikecilkan, label sempit ditaruh di tengah
        var b: Bitmap
        if (label.width > ESC_WIDTH) {
            b = Bitmap.createScaledBitmap(label, ESC_WIDTH, label.height * ESC_WIDTH / label.width, true)
        } else {
            b = Bitmap.createBitmap(ESC_WIDTH, label.height, Bitmap.Config.ARGB_8888)
            val c = Canvas(b)
            c.drawColor(Color.WHITE)
            c.drawBitmap(label, ((ESC_WIDTH - label.width) / 2).toFloat(), 0f, null)
        }
        if (rotate) b = rotate180(b)

        val w = b.width
        val h = b.height
        val bl = black(b)
        val wb = (w + 7) / 8
        val img = ByteArrayOutputStream()
        img.write(byteArrayOf(
            0x1D, 0x76, 0x30, 0x00,
            (wb and 0xFF).toByte(), ((wb shr 8) and 0xFF).toByte(),
            (h and 0xFF).toByte(), ((h shr 8) and 0xFF).toByte()
        ))
        for (y in 0 until h) for (xb in 0 until wb) {
            var v = 0
            for (bit in 0 until 8) {
                val x = xb * 8 + bit
                if (x < w && bl[y * w + x]) v = v or (0x80 shr bit)
            }
            img.write(v)
        }
        val one = img.toByteArray()
        val feed = (hMm + gapMm) * DOTS_PER_MM - h

        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x1B, 0x40))
        repeat(copies.coerceIn(1, 999)) {
            out.write(one)
            var f = feed
            while (f > 0) {
                val n = minOf(f, 255)
                out.write(byteArrayOf(0x1B, 0x4A, n.toByte()))
                f -= n
            }
        }
        return out.toByteArray()
    }

    /** Printer label khusus (TSPL): Xprinter label, HPRT, Gprinter, dll. */
    fun tspl(label: Bitmap, wMm: Int, hMm: Int, copies: Int, gapMm: Int, rotate: Boolean): ByteArray {
        val w = label.width
        val h = label.height
        val bl = black(label)
        val wb = (w + 7) / 8
        val out = ByteArrayOutputStream()
        val head = "SIZE $wMm mm,$hMm mm\r\n" +
            "GAP $gapMm mm,0 mm\r\n" +
            "DIRECTION ${if (rotate) 1 else 0}\r\n" +
            "REFERENCE 0,0\r\n" +
            "CLS\r\n" +
            "BITMAP 0,0,$wb,$h,0,"
        out.write(head.toByteArray(Charsets.US_ASCII))
        for (y in 0 until h) for (xb in 0 until wb) {
            var v = 0xFF // TSPL: bit 1 = putih
            for (bit in 0 until 8) {
                val x = xb * 8 + bit
                if (x < w && bl[y * w + x]) v = v and (0x80 shr bit).inv()
            }
            out.write(v and 0xFF)
        }
        out.write("\r\nPRINT 1,${copies.coerceIn(1, 999)}\r\n".toByteArray(Charsets.US_ASCII))
        return out.toByteArray()
    }
}
