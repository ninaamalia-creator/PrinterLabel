package com.simple.labelprint

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

@SuppressLint("MissingPermission")
class MainActivity : Activity() {

    private val reqPerm = 1
    private val reqImage = 2

    /** Ukuran label (lebar x tinggi mm). Baris terakhir = kustom. */
    private val papers = listOf(
        30 to 20, 40 to 20, 40 to 30, 50 to 20, 50 to 25,
        50 to 30, 50 to 40, 58 to 30, 58 to 40, 58 to 50
    )
    private val sizes = listOf(0, 20, 28, 36, 48, 64)
    private val sizeNames = listOf("Huruf otomatis", "Huruf kecil", "Huruf sedang", "Huruf besar", "Huruf sangat besar", "Huruf jumbo")

    private var adapter: BluetoothAdapter? = null
    private lateinit var printer: PrinterConnection
    private var devices: List<BluetoothDevice> = emptyList()
    private var image: Bitmap? = null
    private var ready = false
    @Volatile private var busy = false

    private lateinit var spPrinter: Spinner
    private lateinit var tvDot: TextView
    private lateinit var tvStatus: TextView
    private lateinit var rbTspl: RadioButton
    private lateinit var rbEscpos: RadioButton
    private lateinit var tvTsplWarn: TextView
    private lateinit var spPaper: Spinner
    private lateinit var rowCustom: View
    private lateinit var etCustW: EditText
    private lateinit var etCustH: EditText
    private lateinit var etGap: EditText
    private lateinit var etText: EditText
    private lateinit var spSize: Spinner
    private lateinit var spAlign: Spinner
    private lateinit var cbBold: CheckBox
    private lateinit var cbDither: CheckBox
    private lateinit var spCode: Spinner
    private lateinit var etCode: EditText
    private lateinit var cbCodeText: CheckBox
    private lateinit var spFrame: Spinner
    private lateinit var tvPreviewTitle: TextView
    private lateinit var ivPreview: ImageView
    private lateinit var tvWarn: TextView
    private lateinit var cbRotate: CheckBox
    private lateinit var etCopies: EditText
    private lateinit var btnPrint: Button

    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }
    private val imageFile by lazy { File(filesDir, "logo.png") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        printer = PrinterConnection(adapter)

        spPrinter = findViewById(R.id.spPrinter)
        tvDot = findViewById(R.id.tvDot)
        tvStatus = findViewById(R.id.tvStatus)
        rbTspl = findViewById(R.id.rbTspl)
        rbEscpos = findViewById(R.id.rbEscpos)
        tvTsplWarn = findViewById(R.id.tvTsplWarn)
        spPaper = findViewById(R.id.spPaper)
        rowCustom = findViewById(R.id.rowCustom)
        etCustW = findViewById(R.id.etCustW)
        etCustH = findViewById(R.id.etCustH)
        etGap = findViewById(R.id.etGap)
        etText = findViewById(R.id.etText)
        spSize = findViewById(R.id.spSize)
        spAlign = findViewById(R.id.spAlign)
        cbBold = findViewById(R.id.cbBold)
        cbDither = findViewById(R.id.cbDither)
        spCode = findViewById(R.id.spCode)
        etCode = findViewById(R.id.etCode)
        cbCodeText = findViewById(R.id.cbCodeText)
        spFrame = findViewById(R.id.spFrame)
        tvPreviewTitle = findViewById(R.id.tvPreviewTitle)
        ivPreview = findViewById(R.id.ivPreview)
        tvWarn = findViewById(R.id.tvWarn)
        cbRotate = findViewById(R.id.cbRotate)
        etCopies = findViewById(R.id.etCopies)
        btnPrint = findViewById(R.id.btnPrint)

        setItems(spPaper, papers.map { "${it.first} x ${it.second} mm" } + "Ukuran lain (isi sendiri)")
        setItems(spSize, sizeNames)
        setItems(spAlign, listOf("Rata tengah", "Rata kiri", "Rata kanan"))
        setItems(spCode, Label.CODE_TYPES.map { it.first })
        setItems(spFrame, Label.FRAMES)

        // Pulihkan pengaturan terakhir
        if (prefs.getBoolean("tspl", false)) rbTspl.isChecked = true else rbEscpos.isChecked = true
        spPaper.setSelection(prefs.getInt("paper", 3).coerceIn(0, papers.size))
        etCustW.setText(prefs.getInt("custW", 50).toString())
        etCustH.setText(prefs.getInt("custH", 20).toString())
        etGap.setText(prefs.getInt("gap", 2).toString())
        etText.setText(prefs.getString("text", ""))
        spSize.setSelection(prefs.getInt("size", 0).coerceIn(0, sizes.size - 1))
        spAlign.setSelection(prefs.getInt("align", 0).coerceIn(0, 2))
        cbBold.isChecked = prefs.getBoolean("bold", true)
        cbDither.isChecked = prefs.getBoolean("dither", false)
        spCode.setSelection(prefs.getInt("code", 0).coerceIn(0, Label.CODE_TYPES.size - 1))
        etCode.setText(prefs.getString("codeText", ""))
        cbCodeText.isChecked = prefs.getBoolean("codeShow", true)
        spFrame.setSelection(prefs.getInt("frame", 0).coerceIn(0, Label.FRAMES.size - 1))
        cbRotate.isChecked = prefs.getBoolean("rotate", false)
        if (imageFile.exists()) image = BitmapFactory.decodeFile(imageFile.absolutePath)
        updateModeWarning()

        // Perbarui preview setiap ada perubahan
        val onSelect = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = updatePreview()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        listOf(spPaper, spSize, spAlign, spCode, spFrame).forEach { it.onItemSelectedListener = onSelect }
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = updatePreview()
        }
        listOf(etText, etCode, etCustW, etCustH, etGap).forEach { it.addTextChangedListener(watcher) }
        listOf(cbBold, cbDither, cbCodeText, cbRotate).forEach { it.setOnCheckedChangeListener { _, _ -> updatePreview() } }
        findViewById<RadioGroup>(R.id.rgMode).setOnCheckedChangeListener { _, _ ->
            updateModeWarning()
            saveSettings()
        }

        findViewById<Button>(R.id.btnRefresh).setOnClickListener { loadPrinters() }
        findViewById<Button>(R.id.btnConnect).setOnClickListener { connectSelected() }
        findViewById<Button>(R.id.btnPickImage).setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT).setType("image/*")
            startActivityForResult(Intent.createChooser(i, "Pilih gambar"), reqImage)
        }
        findViewById<Button>(R.id.btnClearImage).setOnClickListener {
            image = null
            imageFile.delete()
            updatePreview()
        }
        btnPrint.setOnClickListener { print() }

        ready = true
        updatePreview()
        if (hasBtPermission()) loadPrinters() else requestBtPermission()
    }

    override fun onDestroy() {
        printer.close()
        super.onDestroy()
    }

    // ---------- UI ----------

    private fun setItems(sp: Spinner, items: List<String>) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun setStatus(msg: String, color: String) = runOnUiThread {
        tvStatus.text = msg
        tvDot.setTextColor(Color.parseColor(color))
    }
    private fun statusIdle(msg: String) = setStatus(msg, "#9E9E9E")
    private fun statusBusy(msg: String) = setStatus(msg, "#FB8C00")
    private fun statusOk(msg: String) = setStatus(msg, "#43A047")
    private fun statusErr(msg: String) = setStatus(msg, "#E53935")

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    private fun updateModeWarning() {
        tvTsplWarn.visibility = if (rbTspl.isChecked) View.VISIBLE else View.GONE
    }

    /** Ukuran label yang dipilih (mm). */
    private fun paperSize(): Pair<Int, Int> {
        val pos = spPaper.selectedItemPosition
        return if (pos in papers.indices) {
            rowCustom.visibility = View.GONE
            papers[pos]
        } else {
            rowCustom.visibility = View.VISIBLE
            val w = (etCustW.text.toString().toIntOrNull() ?: 50).coerceIn(15, 80)
            val h = (etCustH.text.toString().toIntOrNull() ?: 20).coerceIn(10, 150)
            w to h
        }
    }

    private fun alignValue(): Int = when (spAlign.selectedItemPosition) { 1 -> 0; 2 -> 2; else -> 1 }

    private fun buildSpec(): LabelSpec {
        val (w, h) = paperSize()
        return LabelSpec(
            wMm = w,
            hMm = h,
            text = etText.text.toString(),
            sizePx = sizes[spSize.selectedItemPosition.coerceIn(0, sizes.size - 1)],
            bold = cbBold.isChecked,
            align = alignValue(),
            frame = spFrame.selectedItemPosition.coerceIn(0, Label.FRAMES.size - 1),
            image = image,
            dither = cbDither.isChecked,
            codeFormat = Label.CODE_TYPES[spCode.selectedItemPosition.coerceIn(0, Label.CODE_TYPES.size - 1)].second,
            codeText = etCode.text.toString(),
            codeShowText = cbCodeText.isChecked
        )
    }

    private fun updatePreview() {
        if (!ready) return
        val spec = buildSpec()
        val r = Label.render(spec)
        ivPreview.setImageBitmap(r.bitmap)
        tvPreviewTitle.text = "👁  PREVIEW  (${spec.wMm} x ${spec.hMm} mm)"
        tvWarn.text = r.warning ?: ""
        tvWarn.visibility = if (r.warning != null) View.VISIBLE else View.GONE
        saveSettings()
    }

    private fun saveSettings() {
        if (!ready) return
        prefs.edit()
            .putBoolean("tspl", rbTspl.isChecked)
            .putInt("paper", spPaper.selectedItemPosition)
            .putInt("custW", etCustW.text.toString().toIntOrNull() ?: 50)
            .putInt("custH", etCustH.text.toString().toIntOrNull() ?: 20)
            .putInt("gap", etGap.text.toString().toIntOrNull() ?: 2)
            .putString("text", etText.text.toString())
            .putInt("size", spSize.selectedItemPosition)
            .putInt("align", spAlign.selectedItemPosition)
            .putBoolean("bold", cbBold.isChecked)
            .putBoolean("dither", cbDither.isChecked)
            .putInt("code", spCode.selectedItemPosition)
            .putString("codeText", etCode.text.toString())
            .putBoolean("codeShow", cbCodeText.isChecked)
            .putInt("frame", spFrame.selectedItemPosition)
            .putBoolean("rotate", cbRotate.isChecked)
            .apply()
    }

    // ---------- Gambar ----------

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqImage && resultCode == RESULT_OK) data?.data?.let { loadImage(it) }
    }

    private fun loadImage(uri: Uri) {
        try {
            val opt = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opt) }
            var sample = 1
            while (opt.outWidth / (sample * 2) >= 500 && opt.outHeight / (sample * 2) >= 500) sample *= 2
            val opt2 = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opt2) }
            if (bmp == null) { toast("Gambar tidak bisa dibuka"); return }
            image = bmp
            FileOutputStream(imageFile).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            updatePreview()
        } catch (e: Exception) {
            toast("Gagal membuka gambar: ${e.message}")
        }
    }

    // ---------- Bluetooth ----------

    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun requestBtPermission() {
        if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), reqPerm)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqPerm) {
            if (hasBtPermission()) loadPrinters() else statusErr("Izin Bluetooth ditolak. Aktifkan di Pengaturan > Aplikasi.")
        }
    }

    private fun loadPrinters() {
        if (!hasBtPermission()) { requestBtPermission(); return }
        val a = adapter
        if (a == null) { statusErr("HP ini tidak punya Bluetooth"); return }
        if (!a.isEnabled) { statusErr("Bluetooth mati. Nyalakan dulu, lalu tekan Muat ulang."); return }
        devices = try { a.bondedDevices.toList().sortedBy { it.name ?: "" } } catch (e: Exception) { emptyList() }
        if (devices.isEmpty()) {
            setItems(spPrinter, listOf("Belum ada printer ter-pair"))
            statusErr("Pair printer dulu di Pengaturan Bluetooth HP, lalu tekan Muat ulang.")
            return
        }
        setItems(spPrinter, devices.map { "${it.name ?: "Tanpa nama"}  •  ${it.address}" })
        val idx = devices.indexOfFirst { it.address == prefs.getString("printer", null) }
        if (idx >= 0) spPrinter.setSelection(idx)
        if (printer.isConnected) statusOk("Tersambung") else statusIdle("Pilih printer lalu tekan Sambungkan")
    }

    private fun selectedDevice(): BluetoothDevice? = devices.getOrNull(spPrinter.selectedItemPosition)

    private fun connectSelected() {
        val d = selectedDevice() ?: run { toast("Pilih printer dulu"); return }
        if (busy) return
        busy = true
        statusBusy("Menyambungkan ke ${d.name}...")
        Thread {
            try {
                printer.connect(d)
                prefs.edit().putString("printer", d.address).apply()
                statusOk("Tersambung ke ${d.name}")
            } catch (e: Exception) {
                statusErr("Gagal tersambung. Pastikan printer menyala & tidak dipakai HP lain.")
            } finally {
                busy = false
            }
        }.start()
    }

    private fun print() {
        if (busy) return
        val d = selectedDevice() ?: run { toast("Pilih printer dulu"); return }
        val spec = buildSpec()
        if (spec.text.isBlank() && spec.image == null && (spec.codeFormat == null || spec.codeText.isBlank())) {
            toast("Label masih kosong")
            return
        }
        val result = Label.render(spec)
        val copies = (etCopies.text.toString().toIntOrNull() ?: 1).coerceIn(1, 999)
        val gap = (etGap.text.toString().toIntOrNull() ?: 2).coerceIn(0, 10)
        val rotate = cbRotate.isChecked
        val tspl = rbTspl.isChecked
        saveSettings()

        busy = true
        btnPrint.isEnabled = false
        statusBusy("Mencetak $copies label...")
        Thread {
            try {
                val data = if (tspl) {
                    Label.tspl(result.bitmap, spec.wMm, spec.hMm, copies, gap, rotate)
                } else {
                    Label.escpos(result.bitmap, spec.hMm, copies, gap, rotate)
                }
                if (!printer.isConnected || printer.address != d.address) {
                    statusBusy("Menyambungkan ke ${d.name}...")
                    printer.connect(d)
                    prefs.edit().putString("printer", d.address).apply()
                }
                try {
                    printer.write(data)
                } catch (e: Exception) {
                    printer.connect(d)
                    printer.write(data)
                }
                statusOk("Selesai: $copies label dicetak (${d.name})")
            } catch (e: Exception) {
                statusErr("Gagal mencetak: ${e.message}")
            } finally {
                busy = false
                runOnUiThread { btnPrint.isEnabled = true }
            }
        }.start()
    }
}
