plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.simple.labelprint"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.simple.labelprint"
        minSdk = 21
        targetSdk = 34
        versionCode = 3
        versionName = "2.0"
    }

    signingConfigs {
        create("tetap") {
            storeFile = file("signing.jks")
            storePassword = "labelprinter"
            keyAlias = "label"
            keyPassword = "labelprinter"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("tetap")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("com.google.zxing:core:3.5.3")
}
